ATLAS PWA без Mac

Вариант запуска без Mac:
1. Зарегистрируйся на github.com с iPad.
2. Создай новый репозиторий, например atlas-pwa.
3. Загрузи все файлы из архива atlas_pwa_v1.zip в репозиторий.
4. В Settings -> Pages выбери Deploy from branch, branch main, folder /root.
5. Через 1-3 минуты появится ссылка вида https://username.github.io/atlas-pwa/
6. Открой ссылку на iPad в Safari.
7. Нажми Поделиться -> Добавить на экран Домой.

После этого Atlas будет открываться как приложение. Mac не нужен.
